// FFmpegComponentStore.cpp
#include <C2PlatformSupport.h>
#include <SimpleC2Component.h>
#include "C2FFmpegDecoder.h"

namespace android {

class FFmpegComponentStore : public C2ComponentStore {
public:
    FFmpegComponentStore()
        : SimpleC2ComponentStore([](const std::shared_ptr<C2ComponentInterface>& intf,
                                     const std::shared_ptr<C2Component>& comp) {
            return std::make_shared<SimpleC2Component>(intf, comp);
        }) {
        // Register your decoder here
        addComponent("c2.android.ffmpeg.avc.decoder", CreateCodec2SoftComponentFactory<FFmpegDecoder>());
    }
};
} // namespace android

extern "C" ::C2ComponentStore* CreateCodec2ComponentStore() {
    return new android::FFmpegComponentStore();
}

