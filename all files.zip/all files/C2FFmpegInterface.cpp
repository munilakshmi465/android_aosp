//#include <C2ComponentInterface.h>
#include <C2Config.h>
#include <C2Param.h>



#include <C2Component.h>
#include <C2ParamDef.h>
//#include <C2InterfaceUtils.h>
#include <C2ComponentFactory.h>

class C2FFmpegInterface : public C2InterfaceHelper {
public:
    C2FFmpegInterface(const std::shared_ptr<C2ReflectorHelper>& helper)
        : C2InterfaceHelper(helper) {
        setDerivedInstance(this);

        addParameter(
            DefineParam(mInputFormat, C2_PARAMKEY_INPUT_DELAY)
                .withConstValue(new C2StreamFormatConfig::input(0u, C2FormatCompressed))
                .build());

        addParameter(
            DefineParam(mOutputFormat, C2_PARAMKEY_OUTPUT_DELAY)
                .withConstValue(new C2StreamFormatConfig::output(0u, C2FormatVideo))
                .build());
    }

private:
    std::shared_ptr<C2StreamFormatConfig::input> mInputFormat;
    std::shared_ptr<C2StreamFormatConfig::output> mOutputFormat;
};
