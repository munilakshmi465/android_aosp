#ifndef FFMPEG_DECODER_H
#define FFMPEG_DECODER_H

#include <C2Component.h>
#include <C2BlockPool.h>
#include <C2Buffer.h>
#include <C2Config.h>
#include <memory>
#include <vector>
#include <cstring>  // Fix for memcpy error
#include <libavcodec/avcodec.h>
#include <libswscale/swscale.h>

namespace android {

class FFmpegDecoder : public C2Component {
public:
    explicit FFmpegDecoder(std::shared_ptr<C2ComponentInterface> intf);
    virtual ~FFmpegDecoder();

    // Fix method signatures to match C2Component
    c2_status_t onInit() override;
    c2_status_t onStop() override;
    void onReset() override;
    void onRelease() override;
    c2_status_t onFlush_sm() override;
    void process(std::unique_ptr<C2Work> work, const std::shared_ptr<C2BlockPool>& pool) override;
    c2_status_t drain(uint32_t drainMode, const std::shared_ptr<C2BlockPool>& pool) override;

private:
    std::shared_ptr<C2ComponentInterface> mIntf;
    AVCodecContext* mCodecCtx;
    const AVCodec* mCodec;
    SwsContext* mSwsCtx;
};

} // namespace android

#endif // FFMPEG_DECODER_H

