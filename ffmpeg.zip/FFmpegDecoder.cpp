
#include "FFmpegDecoder.h"
#include <memory>

extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/imgutils.h>
#include <libswscale/swscale.h>
}

namespace android {

class FFmpegDecoder : public C2Component {
public:
    FFmpegDecoder(std::shared_ptr<C2Component::Interface> intf);
    virtual ~FFmpegDecoder();

    c2_status_t onInit() override;
    c2_status_t onStop() override;
    void onReset() override;
    void onRelease() override;
    c2_status_t onFlush_sm() override;
    void process(std::unique_ptr<C2Work> work, const std::shared_ptr<C2BlockPool>& pool) override;
    c2_status_t drain(uint32_t drainMode, const std::shared_ptr<C2BlockPool>& pool) override;

private:
    AVCodecContext* mCodecCtx;
    AVCodec* mCodec;
    SwsContext* mSwsCtx;
};

FFmpegDecoder::FFmpegDecoder(std::shared_ptr<C2Component::Interface> intf)
    : C2Component(intf), mCodecCtx(nullptr), mCodec(nullptr), mSwsCtx(nullptr) {}

FFmpegDecoder::~FFmpegDecoder() {
    onRelease();
}

c2_status_t FFmpegDecoder::onInit() {
    avcodec_register_all();
    mCodec = avcodec_find_decoder(AV_CODEC_ID_H264);
    if (!mCodec) {
        return C2_CORRUPTED;
    }
    mCodecCtx = avcodec_alloc_context3(mCodec);
    if (!mCodecCtx) {
        return C2_NO_MEMORY;
    }
    if (avcodec_open2(mCodecCtx, mCodec, nullptr) < 0) {
        avcodec_free_context(&mCodecCtx);
        return C2_CORRUPTED;
    }
    return C2_OK;
}

void FFmpegDecoder::onRelease() {
    if (mCodecCtx) {
        avcodec_free_context(&mCodecCtx);
        mCodecCtx = nullptr;
    }
    if (mSwsCtx) {
        sws_freeContext(mSwsCtx);
        mSwsCtx = nullptr;
    }

c2_status_t FFmpegDecoder::onStop() {
    return onFlush_sm();
}

void FFmpegDecoder::onReset() {
    onRelease();
    onInit();
}

c2_status_t FFmpegDecoder::onFlush_sm() {
    if (mCodecCtx) {
        avcodec_flush_buffers(mCodecCtx);
    }
    return C2_OK;
}

void FFmpegDecoder::process(std::unique_ptr<C2Work> work, const std::shared_ptr<C2BlockPool>& pool) {
    std::shared_ptr<C2Buffer> inputBuffer = work->input.buffers[0];
    uint8_t* data = inputBuffer->data().linearBlocks().front().map().data();
    size_t size = inputBuffer->data().linearBlocks().front().map().size();

    AVPacket packet;
    av_init_packet(&packet);
    packet.data = data;
    packet.size = size;

    AVFrame* frame = av_frame_alloc();
    if (!frame) {
        work->result = C2_CORRUPTED;
        return;
    }

    if (avcodec_send_packet(mCodecCtx, &packet) == 0) {
        if (avcodec_receive_frame(mCodecCtx, frame) == 0) {
            std::shared_ptr<C2GraphicBlock> block;
            pool->fetchGraphicBlock(mCodecCtx->width, mCodecCtx->height, HAL_PIXEL_FORMAT_YV12,
                                   C2BufferLayout::LAYOUT_TOP_BOTTOM, &block);

            uint8_t* dst = block->map().data();
            memcpy(dst, frame->data[0], mCodecCtx->width * mCodecCtx->height * 3 / 2);

            work->result = C2_OK;
            work->workletsProcessed = 1u;
            work->output.buffers.push_back(C2Buffer::CreateGraphicBuffer(block));
        }
    }

    av_frame_free(&frame);
}

c2_status_t FFmpegDecoder::drain(uint32_t drainMode, const std::shared_ptr<C2BlockPool>& pool) {
    return C2_OK;
}

}  

